def main():
    print("This is the CLI!")

